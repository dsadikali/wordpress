<?php
echo '<script src="http://connect.facebook.net/en_US/all.js"></script>';
?>